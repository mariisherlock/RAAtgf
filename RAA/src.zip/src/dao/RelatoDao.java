package dao;

import model.Relato;
import model.Aluno;
import model.CategoriaRelato;
import model.StatusRelato;
import util.Conexao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RelatoDao {

    public void criarRelato(Relato relato) {
        String sql = "insert into relato (titulo, descricao, local, data, usuario_anonimo, categoria, status, autor_id) values (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = Conexao.getConnection();
             PreparedStatement statement = conn.prepareStatement(sql)
        ){
            statement.setString(1, relato.getTitulo());
            statement.setString(2, relato.getDescricao());
            statement.setString(3, relato.getLocal());
            statement.setDate(4, java.sql.Date.valueOf(relato.getData()));
            statement.setBoolean(5, relato.isUsuarioAnonimo());
            statement.setString(6, relato.getCategoria().name());
            statement.setString(7, relato.getStatus().name());
            statement.setInt(8, relato.getAutor().getId());
            statement.executeUpdate();

            System.out.println("Relato criado com sucesso!");

        } catch (SQLException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

    public List<Relato> mostrarRelatos() {
        List<Relato> relatos = new ArrayList<>();
        String sql = "select r.*, u.nome as nome_autor from relato r inner join usuario u on r.autor_id = u.id";

        try (Connection conn = Conexao.getConnection();
             PreparedStatement statement = conn.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()
        ) {
            while (resultSet.next()) {
                Relato relato = new Relato();

                relato.setId(resultSet.getInt("id"));
                relato.setTitulo(resultSet.getString("titulo"));
                relato.setDescricao(resultSet.getString("descricao"));
                relato.setLocal(resultSet.getString("local"));
                relato.setData(resultSet.getDate("data").toLocalDate());

                relato.setUsuarioAnonimo(resultSet.getBoolean("usuario_anonimo"));

                relato.setCategoria(CategoriaRelato.valueOf(resultSet.getString("categoria")));
                relato.setStatus(StatusRelato.valueOf(resultSet.getString("status")));

                Aluno autor = new Aluno();
                autor.setId(resultSet.getInt("autor_id"));

                autor.setNome(resultSet.getString("nome_autor"));
                relato.setAutor(autor);

                relatos.add(relato);
            }
        } catch (SQLException e) {
            System.out.println("Erro: " + e.getMessage());
        }
        return relatos;
    }

    public void atualizarRelato (Relato relato) {
        String sql = "update relato set titulo = ?, descricao = ?, local = ?, data = ?, usuario_anonimo = ?, categoria = ?, status = ? where id = ?";

        try (Connection conn = Conexao.getConnection();
             PreparedStatement statement = conn.prepareStatement(sql)
        ){
            statement.setString(1, relato.getTitulo());
            statement.setString(2, relato.getDescricao());
            statement.setString(3, relato.getLocal());
            statement.setDate(4, java.sql.Date.valueOf(relato.getData()));
            statement.setBoolean(5, relato.isUsuarioAnonimo());
            statement.setString(6, relato.getCategoria().name());
            statement.setString(7, relato.getStatus().name());

            statement.setInt(8, relato.getId());

            int linhasAfetadas = statement.executeUpdate();

            if (linhasAfetadas > 0) {
                System.out.println("Relato updated com sucesso!");
            } else {
                System.out.println("Relato não encontrado.");
            }

        } catch (SQLException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

    public void deletarRelato(int id) {
        String sql = "delete from relato where id = ?";

        try (Connection conn = Conexao.getConnection();
             PreparedStatement statement = conn.prepareStatement(sql)
        ){
            statement.setInt(1, id);
            int linhasAfetadas = statement.executeUpdate();

            if (linhasAfetadas > 0) {
                System.out.println("Relato removido com sucesso!");
            } else {
                System.out.println("Relato não encontrado.");
            }

        } catch (SQLException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

    // --- NOVA FUNÇÃO DE MODERAÇÃO ADICIONADA ---
    public void analisarRelato(int id, String novoStatus) {
        String sql = "update relato set status = ? where id = ?";

        try (Connection conn = Conexao.getConnection();
             PreparedStatement statement = conn.prepareStatement(sql)
        ) {
            statement.setString(1, novoStatus);
            statement.setInt(2, id);

            int linhasAfetadas = statement.executeUpdate();

            if (linhasAfetadas > 0) {
                System.out.println("Status do relato #" + id + " atualizado para: " + novoStatus);
            } else {
                System.out.println("Relato #" + id + " não encontrado para atualização.");
            }

        } catch (SQLException e) {
            System.out.println("Erro ao atualizar status do relato: " + e.getMessage());
        }
    }

    public List<Relato> listarRelatosDoAluno(int idAutor){

        List<Relato> relatos = new ArrayList<>();

        String sql = """
            SELECT *
            FROM relato
            WHERE autor_id = ?
            ORDER BY data DESC
            """;

        try(Connection conn = Conexao.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)){

            ps.setInt(1,idAutor);

            ResultSet rs = ps.executeQuery();

            while(rs.next()){

                Relato relato = new Relato();

                relato.setId(rs.getInt("id"));
                relato.setTitulo(rs.getString("titulo"));
                relato.setDescricao(rs.getString("descricao"));
                relato.setLocal(rs.getString("local"));
                relato.setData(rs.getDate("data").toLocalDate());

                relato.setCategoria(
                        CategoriaRelato.valueOf(
                                rs.getString("categoria")
                        )
                );

                relato.setStatus(
                        StatusRelato.valueOf(
                                rs.getString("status")
                        )
                );

                relatos.add(relato);

            }

        }catch(Exception e){

            System.out.println(e.getMessage());

        }

        return relatos;

    }
}